Crumbling.hardCodedData=
{
'play':'खेलें',
'backImg':'CrumbleCover'
}